import 'dotenv/config';
import { PrismaClient } from '@prisma/client';

// Avoid creating multiple client instances during dev (e.g. tsx watch / hot reload)
// Attach to globalThis so subsequent imports reuse existing connection.
declare global {
	// eslint-disable-next-line no-var
	var __prisma__: PrismaClient | undefined;
}

const prisma: PrismaClient = globalThis.__prisma__ ?? new PrismaClient();
if (process.env.NODE_ENV !== 'production') {
	globalThis.__prisma__ = prisma;
}

export default prisma;
